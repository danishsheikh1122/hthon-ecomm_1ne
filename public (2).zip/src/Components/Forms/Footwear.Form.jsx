function FootwearForm(){
    return <>
        <h1>Footwear Form</h1>
    </>
}

export default FootwearForm